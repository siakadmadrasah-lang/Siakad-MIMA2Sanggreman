import{u as _,a1 as D,r as n,q as S,j as t,g as h,C as T,F as m,ag as I}from"./index-zJXj7uqh.js";import{K as E}from"./KopSurat-BpLIKn7I.js";import{P as L}from"./PenandatanganDokumen-Ctqvod13.js";import{A as P}from"./arrow-left-CfezF14o.js";import{P as C}from"./printer-BYozXfMq.js";import{T as K}from"./tag-Dn_UXWwQ.js";import{V as b}from"./video-DxUg-u5l.js";const q=({item:e,type:p,onClose:g})=>{const{settings:f}=_(),{requirePrintAuth:u}=D(),[j,M]=n.useState(!0),[w,R]=n.useState(!0),[v,$]=n.useState(!0),[l,G]=n.useState("portrait");n.useEffect(()=>(document.body.classList.add("portal-print-active"),()=>{document.body.classList.remove("portal-print-active")}),[]);const o=f.pengaturan_cetak||{margin_top:1,margin_right:1,margin_bottom:1,margin_left:1};let r=[];if(e.images&&Array.isArray(e.images)&&e.images.length>0?r=e.images.filter(a=>typeof a=="string"&&a.trim().length>0):e.image_url?r=[e.image_url]:e.thumbnail_url&&(r=[e.thumbnail_url]),r.length===0&&e.video_url){const a=S(e.video_url);a&&(r=[a])}const c=e.content||e.description||"",x=a=>{if(!a)return"";try{return new Date(a).toLocaleDateString("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}catch{return a}},y=x(e.created_at||new Date().toISOString()),N=e.event_date?x(e.event_date):"",i=p==="pengumuman",s=p==="galeri",k=`${(e.id||"101").substring(0,8).toUpperCase()}/MAD/${i?"PENG":s?"GAL":"ART"}/${new Date().getFullYear()}`,A=t.jsxs("div",{id:"printable-portal-root",className:"fixed inset-0 z-[9999] bg-slate-900/90 overflow-y-auto font-serif print:static print:bg-white print:overflow-visible",children:[t.jsxs("div",{className:"sticky top-0 z-[10000] bg-white/95 backdrop-blur-md border-b border-slate-200 p-3 sm:p-4 flex justify-between items-center print:hidden shadow-md gap-3",children:[t.jsxs(h,{variant:"outline",size:"sm",onClick:g,className:"font-bold text-slate-700 hover:bg-slate-100 rounded-xl h-9",children:[t.jsx(P,{className:"w-4 h-4 mr-1.5"})," Kembali"]}),t.jsx("div",{className:"flex items-center gap-2",children:t.jsxs(h,{size:"sm",onClick:()=>{u(()=>{window.print()},`${i?"Pengumuman Resmi":s?"Dokumentasi Galeri":"Berita / Artikel"}: ${e.title||"Dokumen"}`)},className:"bg-emerald-600 hover:bg-emerald-700 text-white px-5 font-bold h-9 rounded-xl shadow-md flex items-center gap-2 cursor-pointer text-xs sm:text-sm",children:[t.jsx(C,{className:"w-4 h-4"})," ",t.jsx("span",{children:"Cetak Dokumen"})]})})]}),t.jsx("div",{className:"p-4 md:p-8 flex justify-center print:p-0 print:m-0 print:block",children:t.jsxs("div",{id:"printable-paper",className:"bg-white shadow-2xl print:shadow-none print:w-full flex flex-col justify-between my-2 print:my-0 text-slate-900 border border-slate-200 print:border-none",style:{width:l==="landscape"?"297mm":"210mm",minHeight:l==="landscape"?"210mm":"297mm",padding:`${o.margin_top||1}cm ${o.margin_right||1}cm ${o.margin_bottom||1}cm ${o.margin_left||1}cm`,boxSizing:"border-box"},children:[t.jsxs("div",{children:[j&&t.jsx(E,{}),t.jsxs("div",{className:"text-center my-4 font-serif",children:[t.jsx("h2",{className:"text-xl font-bold uppercase underline tracking-wider text-slate-900 decoration-2 underline-offset-4",children:i?"PENGUMUMAN RESMI":s?"DOKUMENTASI GALERI MADRASAH":"BERITA & ARTIKEL MADRASAH"}),t.jsxs("p",{className:"text-xs font-sans text-slate-600 mt-1 font-medium",children:["Nomor: ",k]})]}),t.jsx("h3",{className:"text-lg md:text-xl font-bold text-center text-slate-900 mt-2 mb-6 uppercase tracking-tight leading-snug font-serif",children:e.title}),t.jsxs("div",{className:"flex flex-wrap items-center justify-between text-[9pt] font-sans text-slate-700 border-y border-slate-300 py-1.5 mb-6",children:[t.jsxs("div",{className:"flex items-center gap-1.5",children:[t.jsx(T,{className:"w-3.5 h-3.5 text-emerald-700"}),t.jsxs("span",{children:[t.jsx("strong",{children:"Tanggal:"})," ",y]})]}),e.author&&t.jsxs("div",{className:"flex items-center gap-1.5",children:[t.jsx(K,{className:"w-3.5 h-3.5 text-emerald-700"}),t.jsxs("span",{children:[t.jsx("strong",{children:"Penulis:"})," ",e.author]})]}),e.category&&!i&&t.jsxs("div",{className:"flex items-center gap-1.5",children:[t.jsx(m,{className:"w-3.5 h-3.5 text-emerald-700"}),t.jsxs("span",{children:[t.jsx("strong",{children:"Kategori:"})," ",e.category]})]}),s&&e.media_type&&t.jsxs("div",{className:"flex items-center gap-1.5",children:[e.media_type==="video"?t.jsx(b,{className:"w-3.5 h-3.5 text-rose-600"}):t.jsx(m,{className:"w-3.5 h-3.5 text-emerald-700"}),t.jsxs("span",{children:[t.jsx("strong",{children:"Tipe Media:"})," ",e.media_type==="video"?"Dokumentasi Video":"Dokumentasi Foto"]})]})]}),i&&(e.event_date||e.event_location||e.event_time)&&t.jsxs("div",{className:"mb-6 border-2 border-slate-800 p-4 font-serif text-[10pt] bg-slate-50/50 print:bg-transparent",children:[t.jsx("p",{className:"font-bold text-slate-900 mb-2 border-b border-slate-400 pb-1 uppercase tracking-wide text-xs",children:"📌 RINCIAN PELAKSANAAN / KEGIATAN:"}),t.jsx("table",{className:"w-full text-left font-serif border-collapse",children:t.jsxs("tbody",{children:[e.event_date&&t.jsxs("tr",{children:[t.jsx("td",{className:"py-1 w-36 font-bold text-slate-900",children:"Hari, Tanggal"}),t.jsx("td",{className:"py-1 w-4 text-center",children:":"}),t.jsx("td",{className:"py-1 text-slate-900",children:N})]}),e.event_time&&t.jsxs("tr",{children:[t.jsx("td",{className:"py-1 w-36 font-bold text-slate-900",children:"Waktu / Jam"}),t.jsx("td",{className:"py-1 w-4 text-center",children:":"}),t.jsxs("td",{className:"py-1 text-slate-900",children:[e.event_time," WIB"]})]}),e.event_location&&t.jsxs("tr",{children:[t.jsx("td",{className:"py-1 w-36 font-bold text-slate-900",children:"Tempat / Lokasi"}),t.jsx("td",{className:"py-1 w-4 text-center",children:":"}),t.jsx("td",{className:"py-1 text-slate-900",children:e.event_location})]})]})})]}),s&&e.video_url&&t.jsxs("div",{className:"mb-6 p-3 bg-slate-50 border border-slate-300 rounded font-sans text-xs",children:[t.jsxs("p",{className:"font-bold text-slate-800 flex items-center gap-1.5",children:[t.jsx(b,{className:"w-3.5 h-3.5 text-rose-600"})," Link Video Dokumentasi:"]}),t.jsx("p",{className:"text-emerald-700 font-mono underline break-all mt-0.5",children:e.video_url})]}),c&&t.jsx("div",{className:"text-[11pt] leading-relaxed text-slate-900 whitespace-pre-wrap text-justify mb-6 font-serif",children:c}),v&&r.length>0&&t.jsxs("div",{className:"mb-6",children:[s&&t.jsxs("div",{className:"flex items-center gap-2 mb-3 pb-1 border-b border-slate-300 font-sans text-xs font-bold text-slate-800",children:[t.jsx(m,{className:"w-4 h-4 text-emerald-700"}),t.jsxs("span",{children:["DOKUMENTASI FOTO KEGIATAN (",r.length," Foto)"]})]}),r.length===1?t.jsxs("div",{className:"relative aspect-[16/9] max-h-[350px] w-full overflow-hidden rounded-lg border border-slate-300 bg-slate-100 print:bg-white my-2 shadow-sm print:shadow-none break-inside-avoid print:break-inside-avoid",children:[t.jsx("img",{src:r[0],alt:e.title,className:"w-full h-full object-cover gallery-img"}),t.jsx("span",{className:"absolute bottom-2 left-2 bg-slate-900/80 text-white text-[8pt] px-2 py-0.5 rounded font-sans font-medium print:border print:border-slate-400 print:bg-slate-800",children:"Foto Dokumentasi"})]}):t.jsx("div",{className:"grid grid-cols-2 gap-3.5 my-2",children:r.map((a,d)=>t.jsxs("div",{className:"relative aspect-[4/3] w-full rounded-lg border border-slate-300 overflow-hidden bg-slate-100 print:bg-white shadow-sm print:shadow-none break-inside-avoid print:break-inside-avoid",children:[t.jsx("img",{src:a,alt:`${e.title} ${d+1}`,className:"w-full h-full object-cover gallery-img"}),t.jsxs("span",{className:"absolute bottom-1.5 left-1.5 bg-slate-900/75 text-white text-[7.5pt] px-1.5 py-0.5 rounded font-sans font-medium print:bg-slate-800 print:border print:border-slate-500",children:["Foto ",d+1]})]},d))})]})]}),t.jsxs("div",{children:[w&&t.jsx("div",{className:"mt-8 break-inside-avoid",children:t.jsx(L,{showGuru:!1})}),t.jsxs("div",{className:"mt-8 pt-2 border-t border-slate-400 text-[8pt] text-slate-600 flex justify-between items-center font-sans",children:[t.jsxs("p",{children:["Dokumen Resmi Madrasah (",s?"Dokumentasi Galeri":i?"Pengumuman":"Artikel",") | Dicetak pada: ",new Date().toLocaleDateString("id-ID",{weekday:"long",year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"})]}),t.jsx("p",{className:"font-semibold",children:"Si@Kad Madrasah"})]})]})]})}),t.jsx("style",{dangerouslySetInnerHTML:{__html:`
        @media print { 
          /* Completely hide main app container #root and all non-printable portals from print flow */
          #root,
          body.portal-print-active #root,
          body > *:not(#printable-portal-root) { 
            display: none !important;
            height: 0 !important;
            max-height: 0 !important;
            overflow: hidden !important;
            visibility: hidden !important;
            opacity: 0 !important;
            position: absolute !important;
            top: -9999px !important;
            left: -9999px !important;
          }

          @page { 
            size: A4 ${l}; 
            margin: 10mm 12mm; 
          } 

          html, body { 
            background: #ffffff !important; 
            color: #000000 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            overflow: visible !important;
          } 

          #printable-portal-root,
          div#printable-portal-root,
          body > #printable-portal-root { 
            display: block !important;
            position: absolute !important;
            top: 0 !important;
            left: 0 !important;
            width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            background: #ffffff !important;
            margin: 0 !important;
            padding: 0 !important;
            overflow: visible !important;
            z-index: 9999999 !important;
            visibility: visible !important;
            float: none !important;
          } 

          #printable-portal-root * {
            visibility: visible !important;
          }

          #printable-paper { 
            box-shadow: none !important;
            border: none !important;
            margin: 0 auto !important;
            padding: 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            background: #ffffff !important;
            color: #000000 !important;
            display: block !important;
            page-break-inside: auto !important;
            break-inside: auto !important;
          } 

          #printable-portal-root img.gallery-img {
            width: 100% !important;
            height: 100% !important;
            object-fit: cover !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          #printable-portal-root img:not(.gallery-img) {
            max-width: 100% !important;
            max-height: 12cm !important;
            object-fit: contain !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          .print\\:hidden,
          .print\\:hidden *,
          [class*="print:hidden"] { 
            display: none !important; 
            height: 0 !important;
            overflow: hidden !important;
          } 
        }
      `}})]});return I.createPortal(A,document.body)};export{q as C};
