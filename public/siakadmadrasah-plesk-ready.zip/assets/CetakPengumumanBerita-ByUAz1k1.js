import{u as P,a1 as C,r as o,q as I,j as e,g as d,C as L,F as c,af as $}from"./index-B43peNHy.js";import{K as E}from"./KopSurat-CceKkUZz.js";import{P as K}from"./PenandatanganDokumen-W4AbxoKw.js";import{P as R}from"./PrintSecurityIndicator-4L_0h_ni.js";import{A as G}from"./arrow-left-D4p2pbex.js";import{P as M}from"./printer-C1vzrX3r.js";import{T as F}from"./tag-CsuJWJcD.js";import{V as j}from"./video-DxNHNnax.js";const Y=({item:t,type:p,onClose:w})=>{const{settings:v}=P(),{requirePrintAuth:y}=C(),[x,N]=o.useState(!0),[h,k]=o.useState(!0),[b,A]=o.useState(!0),[n,g]=o.useState("portrait");o.useEffect(()=>(document.body.classList.add("portal-print-active"),()=>{document.body.classList.remove("portal-print-active")}),[]);const l=v.pengaturan_cetak||{margin_top:1,margin_right:1,margin_bottom:1,margin_left:1};let r=[];if(t.images&&Array.isArray(t.images)&&t.images.length>0?r=t.images.filter(a=>typeof a=="string"&&a.trim().length>0):t.image_url?r=[t.image_url]:t.thumbnail_url&&(r=[t.thumbnail_url]),r.length===0&&t.video_url){const a=I(t.video_url);a&&(r=[a])}const u=t.content||t.description||"",f=a=>{if(!a)return"";try{return new Date(a).toLocaleDateString("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}catch{return a}},_=f(t.created_at||new Date().toISOString()),D=t.event_date?f(t.event_date):"",i=p==="pengumuman",s=p==="galeri",S=`${(t.id||"101").substring(0,8).toUpperCase()}/MAD/${i?"PENG":s?"GAL":"ART"}/${new Date().getFullYear()}`,T=e.jsxs("div",{id:"printable-portal-root",className:"fixed inset-0 z-[9999] bg-slate-900/90 overflow-y-auto font-serif print:static print:bg-white print:overflow-visible",children:[e.jsxs("div",{className:"sticky top-0 z-[10000] bg-white border-b border-slate-200 p-4 flex flex-wrap justify-between items-center print:hidden shadow-md gap-3",children:[e.jsxs(d,{variant:"ghost",onClick:w,className:"font-bold text-slate-700 hover:bg-slate-100",children:[e.jsx(G,{className:"w-4 h-4 mr-2"})," Kembali"]}),e.jsxs("div",{className:"flex flex-wrap items-center gap-3",children:[e.jsxs("label",{className:"flex items-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200",children:[e.jsx("input",{type:"checkbox",checked:x,onChange:a=>N(a.target.checked),className:"rounded text-emerald-600 focus:ring-emerald-500"}),"Kop Surat"]}),e.jsxs("label",{className:"flex items-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200",children:[e.jsx("input",{type:"checkbox",checked:h,onChange:a=>k(a.target.checked),className:"rounded text-emerald-600 focus:ring-emerald-500"}),"Penandatangan"]}),r.length>0&&e.jsxs("label",{className:"flex items-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200",children:[e.jsx("input",{type:"checkbox",checked:b,onChange:a=>A(a.target.checked),className:"rounded text-emerald-600 focus:ring-emerald-500"}),"Gambar / Foto"]}),e.jsxs("div",{className:"flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200",children:[e.jsx(d,{size:"sm",variant:n==="portrait"?"default":"ghost",onClick:()=>g("portrait"),className:`h-7 text-xs font-bold rounded-lg ${n==="portrait"?"bg-slate-800 text-white":"text-slate-600"}`,children:"Portrait"}),e.jsx(d,{size:"sm",variant:n==="landscape"?"default":"ghost",onClick:()=>g("landscape"),className:`h-7 text-xs font-bold rounded-lg ${n==="landscape"?"bg-slate-800 text-white":"text-slate-600"}`,children:"Landscape"})]}),e.jsx(R,{documentTitle:`${i?"Pengumuman Resmi":s?"Dokumentasi Galeri":"Berita / Artikel"}: ${t.title||"Dokumen"}`}),e.jsxs(d,{onClick:()=>{y(()=>{window.print()},`${i?"Pengumuman Resmi":s?"Dokumentasi Galeri":"Berita / Artikel"}: ${t.title||"Dokumen"}`)},className:"bg-emerald-600 hover:bg-emerald-700 text-white px-6 font-bold h-10 rounded-xl shadow-lg flex items-center gap-2 cursor-pointer",children:[e.jsx(M,{className:"w-4 h-4"})," Cetak Dokumen"]})]})]}),e.jsx("div",{className:"p-4 md:p-8 flex justify-center print:p-0 print:m-0 print:block",children:e.jsxs("div",{id:"printable-paper",className:"bg-white shadow-2xl print:shadow-none print:w-full flex flex-col justify-between my-2 print:my-0 text-slate-900 border border-slate-200 print:border-none",style:{width:n==="landscape"?"297mm":"210mm",minHeight:n==="landscape"?"210mm":"297mm",padding:`${l.margin_top||1}cm ${l.margin_right||1}cm ${l.margin_bottom||1}cm ${l.margin_left||1}cm`,boxSizing:"border-box"},children:[e.jsxs("div",{children:[x&&e.jsx(E,{}),e.jsxs("div",{className:"text-center my-4 font-serif",children:[e.jsx("h2",{className:"text-xl font-bold uppercase underline tracking-wider text-slate-900 decoration-2 underline-offset-4",children:i?"PENGUMUMAN RESMI":s?"DOKUMENTASI GALERI MADRASAH":"BERITA & ARTIKEL MADRASAH"}),e.jsxs("p",{className:"text-xs font-sans text-slate-600 mt-1 font-medium",children:["Nomor: ",S]})]}),e.jsx("h3",{className:"text-lg md:text-xl font-bold text-center text-slate-900 mt-2 mb-6 uppercase tracking-tight leading-snug font-serif",children:t.title}),e.jsxs("div",{className:"flex flex-wrap items-center justify-between text-[9pt] font-sans text-slate-700 border-y border-slate-300 py-1.5 mb-6",children:[e.jsxs("div",{className:"flex items-center gap-1.5",children:[e.jsx(L,{className:"w-3.5 h-3.5 text-emerald-700"}),e.jsxs("span",{children:[e.jsx("strong",{children:"Tanggal:"})," ",_]})]}),t.author&&e.jsxs("div",{className:"flex items-center gap-1.5",children:[e.jsx(F,{className:"w-3.5 h-3.5 text-emerald-700"}),e.jsxs("span",{children:[e.jsx("strong",{children:"Penulis:"})," ",t.author]})]}),t.category&&!i&&e.jsxs("div",{className:"flex items-center gap-1.5",children:[e.jsx(c,{className:"w-3.5 h-3.5 text-emerald-700"}),e.jsxs("span",{children:[e.jsx("strong",{children:"Kategori:"})," ",t.category]})]}),s&&t.media_type&&e.jsxs("div",{className:"flex items-center gap-1.5",children:[t.media_type==="video"?e.jsx(j,{className:"w-3.5 h-3.5 text-rose-600"}):e.jsx(c,{className:"w-3.5 h-3.5 text-emerald-700"}),e.jsxs("span",{children:[e.jsx("strong",{children:"Tipe Media:"})," ",t.media_type==="video"?"Dokumentasi Video":"Dokumentasi Foto"]})]})]}),i&&(t.event_date||t.event_location||t.event_time)&&e.jsxs("div",{className:"mb-6 border-2 border-slate-800 p-4 font-serif text-[10pt] bg-slate-50/50 print:bg-transparent",children:[e.jsx("p",{className:"font-bold text-slate-900 mb-2 border-b border-slate-400 pb-1 uppercase tracking-wide text-xs",children:"📌 RINCIAN PELAKSANAAN / KEGIATAN:"}),e.jsx("table",{className:"w-full text-left font-serif border-collapse",children:e.jsxs("tbody",{children:[t.event_date&&e.jsxs("tr",{children:[e.jsx("td",{className:"py-1 w-36 font-bold text-slate-900",children:"Hari, Tanggal"}),e.jsx("td",{className:"py-1 w-4 text-center",children:":"}),e.jsx("td",{className:"py-1 text-slate-900",children:D})]}),t.event_time&&e.jsxs("tr",{children:[e.jsx("td",{className:"py-1 w-36 font-bold text-slate-900",children:"Waktu / Jam"}),e.jsx("td",{className:"py-1 w-4 text-center",children:":"}),e.jsxs("td",{className:"py-1 text-slate-900",children:[t.event_time," WIB"]})]}),t.event_location&&e.jsxs("tr",{children:[e.jsx("td",{className:"py-1 w-36 font-bold text-slate-900",children:"Tempat / Lokasi"}),e.jsx("td",{className:"py-1 w-4 text-center",children:":"}),e.jsx("td",{className:"py-1 text-slate-900",children:t.event_location})]})]})})]}),s&&t.video_url&&e.jsxs("div",{className:"mb-6 p-3 bg-slate-50 border border-slate-300 rounded font-sans text-xs",children:[e.jsxs("p",{className:"font-bold text-slate-800 flex items-center gap-1.5",children:[e.jsx(j,{className:"w-3.5 h-3.5 text-rose-600"})," Link Video Dokumentasi:"]}),e.jsx("p",{className:"text-emerald-700 font-mono underline break-all mt-0.5",children:t.video_url})]}),u&&e.jsx("div",{className:"text-[11pt] leading-relaxed text-slate-900 whitespace-pre-wrap text-justify mb-6 font-serif",children:u}),b&&r.length>0&&e.jsxs("div",{className:"mb-6",children:[s&&e.jsxs("div",{className:"flex items-center gap-2 mb-3 pb-1 border-b border-slate-300 font-sans text-xs font-bold text-slate-800",children:[e.jsx(c,{className:"w-4 h-4 text-emerald-700"}),e.jsxs("span",{children:["DOKUMENTASI FOTO KEGIATAN (",r.length," Foto)"]})]}),r.length===1?e.jsxs("div",{className:"relative aspect-[16/9] max-h-[350px] w-full overflow-hidden rounded-lg border border-slate-300 bg-slate-100 print:bg-white my-2 shadow-sm print:shadow-none break-inside-avoid print:break-inside-avoid",children:[e.jsx("img",{src:r[0],alt:t.title,className:"w-full h-full object-cover gallery-img"}),e.jsx("span",{className:"absolute bottom-2 left-2 bg-slate-900/80 text-white text-[8pt] px-2 py-0.5 rounded font-sans font-medium print:border print:border-slate-400 print:bg-slate-800",children:"Foto Dokumentasi"})]}):e.jsx("div",{className:"grid grid-cols-2 gap-3.5 my-2",children:r.map((a,m)=>e.jsxs("div",{className:"relative aspect-[4/3] w-full rounded-lg border border-slate-300 overflow-hidden bg-slate-100 print:bg-white shadow-sm print:shadow-none break-inside-avoid print:break-inside-avoid",children:[e.jsx("img",{src:a,alt:`${t.title} ${m+1}`,className:"w-full h-full object-cover gallery-img"}),e.jsxs("span",{className:"absolute bottom-1.5 left-1.5 bg-slate-900/75 text-white text-[7.5pt] px-1.5 py-0.5 rounded font-sans font-medium print:bg-slate-800 print:border print:border-slate-500",children:["Foto ",m+1]})]},m))})]})]}),e.jsxs("div",{children:[h&&e.jsx("div",{className:"mt-8 break-inside-avoid",children:e.jsx(K,{showGuru:!1})}),e.jsxs("div",{className:"mt-8 pt-2 border-t border-slate-400 text-[8pt] text-slate-600 flex justify-between items-center font-sans",children:[e.jsxs("p",{children:["Dokumen Resmi Madrasah (",s?"Dokumentasi Galeri":i?"Pengumuman":"Artikel",") | Dicetak pada: ",new Date().toLocaleDateString("id-ID",{weekday:"long",year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"})]}),e.jsx("p",{className:"font-semibold",children:"Si@Kad Madrasah"})]})]})]})}),e.jsx("style",{dangerouslySetInnerHTML:{__html:`
        @media print { 
          /* Completely hide main app container #root and all non-printable portals from print flow */
          #root,
          body.portal-print-active #root,
          body > *:not(#printable-portal-root) { 
            display: none !important;
            height: 0 !important;
            max-height: 0 !important;
            overflow: hidden !important;
            visibility: hidden !important;
            opacity: 0 !important;
            position: absolute !important;
            top: -9999px !important;
            left: -9999px !important;
          }

          @page { 
            size: A4 ${n}; 
            margin: 10mm 12mm; 
          } 

          html, body { 
            background: #ffffff !important; 
            color: #000000 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            overflow: visible !important;
          } 

          #printable-portal-root,
          div#printable-portal-root,
          body > #printable-portal-root { 
            display: block !important;
            position: absolute !important;
            top: 0 !important;
            left: 0 !important;
            width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            background: #ffffff !important;
            margin: 0 !important;
            padding: 0 !important;
            overflow: visible !important;
            z-index: 9999999 !important;
            visibility: visible !important;
            float: none !important;
          } 

          #printable-portal-root * {
            visibility: visible !important;
          }

          #printable-paper { 
            box-shadow: none !important;
            border: none !important;
            margin: 0 auto !important;
            padding: 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            background: #ffffff !important;
            color: #000000 !important;
            display: block !important;
            page-break-inside: auto !important;
            break-inside: auto !important;
          } 

          #printable-portal-root img.gallery-img {
            width: 100% !important;
            height: 100% !important;
            object-fit: cover !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          #printable-portal-root img:not(.gallery-img) {
            max-width: 100% !important;
            max-height: 12cm !important;
            object-fit: contain !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          .print\\:hidden,
          .print\\:hidden *,
          [class*="print:hidden"] { 
            display: none !important; 
            height: 0 !important;
            overflow: hidden !important;
          } 
        }
      `}})]});return $.createPortal(T,document.body)};export{Y as C};
